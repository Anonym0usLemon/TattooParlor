import react from "react";

const Footer = () => {
    return (
        <h3>This is the footer</h3>
    );
}

export default Footer;