import React from "react"; 

const About = () => {
    return (
        <h1>This is an about page!</h1> 
    );
}

export default About; 