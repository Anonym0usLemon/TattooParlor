import React from 'react'; 

const Home = () => {
    return (
        <h1>This is the home page :D</h1>
    );
}

export default Home; 