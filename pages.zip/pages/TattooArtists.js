import react from 'react'; 

const TattooArtists = () => {
    return (
        <h1>Tattoo Artists Page</h1>
    );
}

export default TattooArtists; 